/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  LayoutDashboard, 
  CalendarDays, 
  PlusCircle, 
  CheckCircle2, 
  Circle, 
  Trash2, 
  Clock, 
  BookOpen,
  Search,
  AlertCircle,
  Calendar as CalendarIcon
} from 'lucide-react';

type Priority = 'High' | 'Medium' | 'Low';

interface Task {
  id: string;
  title: string;
  subject: string;
  date: string;
  time: string;
  priority: Priority;
  completed: boolean;
}

// Helper to get today's date in YYYY-MM-DD format based on local timezone
const getTodayString = () => {
  const today = new Date();
  const offset = today.getTimezoneOffset() * 60000;
  return new Date(today.getTime() - offset).toISOString().split('T')[0];
};

// Format date for the task card
const formatDateForCard = (dateStr: string) => {
  const today = getTodayString();
  if (dateStr === today) return 'Today';
  
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const offset = tomorrow.getTimezoneOffset() * 60000;
  const tomorrowStr = new Date(tomorrow.getTime() - offset).toISOString().split('T')[0];
  if (dateStr === tomorrowStr) return 'Tomorrow';

  const [year, month, day] = dateStr.split('-').map(Number);
  const localDate = new Date(year, month - 1, day);
  return localDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
};

const INITIAL_TASKS: Task[] = [
  {
    id: '1',
    title: 'Complete Calculus Assignment',
    subject: 'Math',
    date: getTodayString(),
    time: '14:00',
    priority: 'High',
    completed: false,
  },
  {
    id: '2',
    title: 'Read Chapter 4',
    subject: 'History',
    date: getTodayString(),
    time: '16:30',
    priority: 'Medium',
    completed: true,
  },
  {
    id: '3',
    title: 'Physics Lab Report',
    subject: 'Physics',
    date: new Date(Date.now() + 86400000).toISOString().split('T')[0], // Tomorrow
    time: '10:00',
    priority: 'High',
    completed: false,
  }
];

export default function App() {
  // Initialize state from localStorage or use initial mock data
  const [tasks, setTasks] = useState<Task[]>(() => {
    const saved = localStorage.getItem('student-tasks');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return INITIAL_TASKS;
      }
    }
    return INITIAL_TASKS;
  });

  const [view, setView] = useState<'dashboard' | 'add' | 'schedule'>('dashboard');

  // Save to localStorage whenever tasks change
  useEffect(() => {
    localStorage.setItem('student-tasks', JSON.stringify(tasks));
  }, [tasks]);

  const addTask = (task: Omit<Task, 'id' | 'completed'>) => {
    const newTask: Task = {
      ...task,
      id: crypto.randomUUID(),
      completed: false,
    };
    setTasks(prev => [...prev, newTask]);
    setView('dashboard');
  };

  const toggleTask = (id: string) => {
    setTasks(prev => prev.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
  };

  const deleteTask = (id: string) => {
    setTasks(prev => prev.filter(t => t.id !== id));
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans selection:bg-blue-200">
      {/* Navigation Bar */}
      <nav className="bg-white border-b border-slate-200 sticky top-0 z-20 shadow-sm">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2 text-blue-600 font-bold text-xl tracking-tight">
            <BookOpen className="w-6 h-6" />
            <span className="hidden sm:inline">StudySync</span>
          </div>
          <div className="flex gap-1 sm:gap-2">
            <NavButton view="dashboard" current={view} onClick={setView} icon={<LayoutDashboard className="w-5 h-5" />} label="Dashboard" />
            <NavButton view="schedule" current={view} onClick={setView} icon={<CalendarDays className="w-5 h-5" />} label="Schedule" />
            <NavButton view="add" current={view} onClick={setView} icon={<PlusCircle className="w-5 h-5" />} label="Add Task" />
          </div>
        </div>
      </nav>

      {/* Main Content Area */}
      <main className="max-w-5xl mx-auto p-4 sm:p-6 lg:p-8">
        <AnimatePresence mode="wait">
          {view === 'dashboard' && (
            <DashboardView 
              key="dashboard" 
              tasks={tasks} 
              onToggle={toggleTask} 
              onDelete={deleteTask} 
            />
          )}
          {view === 'schedule' && (
            <ScheduleView 
              key="schedule" 
              tasks={tasks} 
              onToggle={toggleTask} 
              onDelete={deleteTask} 
            />
          )}
          {view === 'add' && (
            <AddTaskView 
              key="add" 
              onAdd={addTask} 
              onCancel={() => setView('dashboard')} 
            />
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}

// --- Components ---

function NavButton({ view, current, onClick, icon, label }: { view: any, current: any, onClick: any, icon: any, label: string }) {
  const isActive = view === current;
  return (
    <button
      onClick={() => onClick(view)}
      className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
        isActive 
          ? 'bg-blue-50 text-blue-700' 
          : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
      }`}
    >
      {icon}
      <span className="hidden sm:inline">{label}</span>
    </button>
  );
}

function DashboardView({ tasks, onToggle, onDelete }: { key?: React.Key, tasks: Task[], onToggle: (id: string) => void, onDelete: (id: string) => void }) {
  const [search, setSearch] = useState('');
  const [priorityFilter, setPriorityFilter] = useState<Priority | 'All'>('All');
  const [subjectFilter, setSubjectFilter] = useState<string>('All');

  const today = getTodayString();
  
  // Get unique subjects for filter dropdown
  const subjects = useMemo(() => {
    const subs = new Set(tasks.map(t => t.subject));
    return ['All', ...Array.from(subs).sort()];
  }, [tasks]);

  const filteredTasks = useMemo(() => {
    return tasks.filter(t => {
      const isSearching = search.trim() !== '';
      // If searching, show all matching tasks. Otherwise, show today's tasks and overdue tasks.
      const isRelevantDate = isSearching ? true : (t.date <= today && !t.completed || t.date === today);
      
      const matchesSearch = t.title.toLowerCase().includes(search.toLowerCase()) || 
                            t.subject.toLowerCase().includes(search.toLowerCase());
      const matchesPriority = priorityFilter === 'All' || t.priority === priorityFilter;
      const matchesSubject = subjectFilter === 'All' || t.subject === subjectFilter;

      return isRelevantDate && matchesSearch && matchesPriority && matchesSubject;
    }).sort((a, b) => {
      if (a.completed !== b.completed) return a.completed ? 1 : -1;
      if (a.date !== b.date) return a.date.localeCompare(b.date);
      return a.time.localeCompare(b.time);
    });
  }, [tasks, search, priorityFilter, subjectFilter, today]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      className="space-y-6"
    >
      <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Today's Tasks</h1>
          <p className="text-slate-500 text-sm mt-1">
            {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
          </p>
        </div>
      </header>

      {/* Search and Filters */}
      <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-200 flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input 
            type="text"
            placeholder="Search tasks..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
          />
        </div>
        <div className="flex gap-2">
          <select
            value={subjectFilter}
            onChange={e => setSubjectFilter(e.target.value)}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            {subjects.map(s => <option key={s} value={s}>{s === 'All' ? 'All Subjects' : s}</option>)}
          </select>
          <select
            value={priorityFilter}
            onChange={e => setPriorityFilter(e.target.value as any)}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="All">All Priorities</option>
            <option value="High">High</option>
            <option value="Medium">Medium</option>
            <option value="Low">Low</option>
          </select>
        </div>
      </div>

      {/* Task List */}
      <div className="space-y-3">
        {filteredTasks.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-xl border border-slate-200 border-dashed">
            <CheckCircle2 className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <h3 className="text-lg font-medium text-slate-900">No tasks found</h3>
            <p className="text-slate-500 text-sm mt-1">
              {search.trim() !== '' ? "Try adjusting your search or filters." : "You're all caught up for today!"}
            </p>
          </div>
        ) : (
          <AnimatePresence mode="popLayout">
            {filteredTasks.map(task => (
              <TaskCard key={task.id} task={task} onToggle={onToggle} onDelete={onDelete} />
            ))}
          </AnimatePresence>
        )}
      </div>
    </motion.div>
  );
}

function ScheduleView({ tasks, onToggle, onDelete }: { key?: React.Key, tasks: Task[], onToggle: (id: string) => void, onDelete: (id: string) => void }) {
  // Group tasks by date
  const groupedTasks = useMemo(() => {
    const groups: Record<string, Task[]> = {};
    tasks.forEach(t => {
      if (!groups[t.date]) groups[t.date] = [];
      groups[t.date].push(t);
    });
    
    // Sort dates
    const sortedDates = Object.keys(groups).sort();
    
    // Sort tasks within each date by time
    sortedDates.forEach(date => {
      groups[date].sort((a, b) => {
        if (a.completed !== b.completed) return a.completed ? 1 : -1;
        return a.time.localeCompare(b.time);
      });
    });
    
    return { groups, sortedDates };
  }, [tasks]);

  const formatDate = (dateStr: string) => {
    const today = getTodayString();
    if (dateStr === today) return 'Today';
    
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const offset = tomorrow.getTimezoneOffset() * 60000;
    const tomorrowStr = new Date(tomorrow.getTime() - offset).toISOString().split('T')[0];
    if (dateStr === tomorrowStr) return 'Tomorrow';
    
    const [year, month, day] = dateStr.split('-').map(Number);
    const localDate = new Date(year, month - 1, day);
    
    return localDate.toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      className="space-y-8"
    >
      <header>
        <h1 className="text-2xl font-bold text-slate-900">Full Schedule</h1>
        <p className="text-slate-500 text-sm mt-1">All your upcoming and past tasks</p>
      </header>

      {groupedTasks.sortedDates.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-2xl border border-slate-200 border-dashed">
          <CalendarIcon className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h3 className="text-lg font-medium text-slate-900">Your schedule is empty</h3>
          <p className="text-slate-500 text-sm mt-1">Add some tasks to see them organized here.</p>
        </div>
      ) : (
        <div className="space-y-8">
          {groupedTasks.sortedDates.map(date => (
            <div key={date} className="space-y-3">
              <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                <CalendarIcon className="w-4 h-4 text-blue-500" />
                {formatDate(date)}
                <span className="text-xs font-medium text-slate-400 bg-slate-100 px-2 py-0.5 rounded-full normal-case">
                  {groupedTasks.groups[date].length} tasks
                </span>
              </h2>
              <div className="space-y-2">
                {groupedTasks.groups[date].map(task => (
                  <TaskCard key={task.id} task={task} onToggle={onToggle} onDelete={onDelete} showDate={false} />
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </motion.div>
  );
}

function AddTaskView({ onAdd, onCancel }: { key?: React.Key, onAdd: (task: Omit<Task, 'id' | 'completed'>) => void, onCancel: () => void }) {
  const [title, setTitle] = useState('');
  const [subject, setSubject] = useState('');
  const [date, setDate] = useState(getTodayString());
  const [time, setTime] = useState('12:00');
  const [priority, setPriority] = useState<Priority>('Medium');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !subject.trim()) return;
    onAdd({ title: title.trim(), subject: subject.trim(), date, time, priority });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      className="max-w-2xl mx-auto"
    >
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50">
          <h2 className="text-xl font-semibold text-slate-900 flex items-center gap-2">
            <PlusCircle className="w-5 h-5 text-blue-500" />
            Create New Task
          </h2>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Task Title</label>
            <input
              type="text"
              required
              value={title}
              onChange={e => setTitle(e.target.value)}
              placeholder="e.g., Read Chapter 5"
              className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Subject</label>
            <input
              type="text"
              required
              value={subject}
              onChange={e => setSubject(e.target.value)}
              placeholder="e.g., Biology"
              className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">Date</label>
              <input
                type="date"
                required
                value={date}
                onChange={e => setDate(e.target.value)}
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">Time</label>
              <input
                type="time"
                required
                value={time}
                onChange={e => setTime(e.target.value)}
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Priority</label>
            <div className="flex gap-3">
              {(['Low', 'Medium', 'High'] as Priority[]).map(p => (
                <label key={p} className="flex-1 cursor-pointer">
                  <input
                    type="radio"
                    name="priority"
                    value={p}
                    checked={priority === p}
                    onChange={() => setPriority(p)}
                    className="sr-only"
                  />
                  <div className={`text-center py-2 px-3 rounded-xl border text-sm font-medium transition-all ${
                    priority === p 
                      ? p === 'High' ? 'bg-red-50 border-red-200 text-red-700'
                        : p === 'Medium' ? 'bg-orange-50 border-orange-200 text-orange-700'
                        : 'bg-green-50 border-green-200 text-green-700'
                      : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                  }`}>
                    {p}
                  </div>
                </label>
              ))}
            </div>
          </div>

          <div className="pt-4 flex gap-3 justify-end">
            <button
              type="button"
              onClick={onCancel}
              className="px-5 py-2.5 text-sm font-medium text-slate-600 hover:bg-slate-100 rounded-xl transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-sm transition-colors"
            >
              Save Task
            </button>
          </div>
        </form>
      </div>
    </motion.div>
  );
}

function TaskCard({ task, onToggle, onDelete, showDate = true }: { key?: React.Key, task: Task, onToggle: (id: string) => void, onDelete: (id: string) => void, showDate?: boolean }) {
  const priorityColors = {
    High: 'bg-red-100 text-red-700 border-red-200',
    Medium: 'bg-orange-100 text-orange-700 border-orange-200',
    Low: 'bg-green-100 text-green-700 border-green-200'
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className={`group flex items-center gap-4 p-4 bg-white rounded-xl border transition-all ${
        task.completed ? 'border-slate-200 opacity-60 bg-slate-50' : 'border-slate-200 shadow-sm hover:shadow-md hover:border-blue-200'
      }`}
    >
      <button 
        onClick={() => onToggle(task.id)}
        className={`flex-shrink-0 transition-colors ${task.completed ? 'text-green-500' : 'text-slate-300 hover:text-blue-500'}`}
      >
        {task.completed ? <CheckCircle2 className="w-6 h-6" /> : <Circle className="w-6 h-6" />}
      </button>

      <div className="flex-1 min-w-0">
        <h3 className={`text-base font-medium truncate transition-all ${task.completed ? 'text-slate-500 line-through' : 'text-slate-900'}`}>
          {task.title}
        </h3>
        <div className="flex flex-wrap items-center gap-3 mt-1.5 text-xs text-slate-500">
          <span className="flex items-center gap-1 bg-slate-100 px-2 py-0.5 rounded-md text-slate-600 font-medium">
            <BookOpen className="w-3 h-3" />
            {task.subject}
          </span>
          <span className="flex items-center gap-1">
            <Clock className="w-3 h-3" />
            {task.time}
          </span>
          {showDate && task.date !== getTodayString() && (
            <span className="flex items-center gap-1">
              <CalendarIcon className="w-3 h-3" />
              {formatDateForCard(task.date)}
            </span>
          )}
          {task.date < getTodayString() && !task.completed && (
            <span className="flex items-center gap-1 text-orange-600 font-medium bg-orange-50 px-2 py-0.5 rounded-md">
              <AlertCircle className="w-3 h-3" />
              Overdue
            </span>
          )}
        </div>
      </div>

      <div className="flex items-center gap-3">
        <span className={`hidden sm:inline-block px-2.5 py-1 rounded-full text-xs font-medium border ${priorityColors[task.priority]}`}>
          {task.priority}
        </span>
        <button
          onClick={() => onDelete(task.id)}
          className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors opacity-0 group-hover:opacity-100 focus:opacity-100"
          aria-label="Delete task"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>
    </motion.div>
  );
}
